// Program Name: Fashion through the decades.
// Creator: Mackenzi Reynolds
// Date: 09/06/2026
// Purpose: Tests user's knowledge of fashion trends throughout different decades.

// Welcomes the user and asks for their name
alert("Hello!\nWelcome to my fashion through the decades quiz!");
let name = prompt (" Before we do the quiz, What is your name?");

if (name == null || name == "" || !/^[a-zA-Z]+$/.test(name)) {
    alert("Invalid. Please enter in your name without special characters or numbers.");
} else {
    alert("Awesome " + name + ", When your ready to start my quiz just click okay!");
}

// Stores the user's score
let score = 0;

// My array that contains my questions, answer options and correct options.
const quiz = [
    {
        questionText: "French designer Paul Poiret changed women's fashion in the 1910s by freeing women from which restrictive daily garment?",
        optionA: "Hoop Skirt",
        optionB: "The corset",
        optionC: "Petticoat",
        optionD: "Bustle",
        answer: "B"
    },
    {
        questionText: "What two international pop stars made denim jeans an everyday fashion statement in the 1950s?",
        optionA: "James Dean and Marilyn Monroe",
        optionB: "Elvis Presley and Marilyn Monroe",
        optionC: "Audrey Hepburn and Coco Chanel",
        optionD: "Princess Diana and Audrey Hepburn",
        answer: "A"
        
    },
    {
        questionText: "Suits featuring massive and structured shoulder pads became a fashion staple of which decade?",
        optionA: "2000",
        optionB: "1990",
        optionC: "1970",
        optionD: "1980",
        answer: "D"
    
    },
    {
        questionText: "In 2010, what print of skinny jeans became the most popular?",
        optionA: "Leopard Print",
        optionB: "Floral pattern",
        optionC: "Camouflage",
        optionD: "Bright colours",
        answer: "A"
        
    },
    {
        questionText: "In 2020, what was the biggest and most global fashion trend?",
        optionA: "Tennis skirts",
        optionB: "Colour-block t-shirts",
        optionC: "Loungewear",
        optionD: "Skinny jeans",
        answer: "C"
}
];

// Function checks whether the user's answer is correct or not
function checkAnswer(question, userAnswer) {
    userAnswer = userAnswer.toUpperCase();
    
if (userAnswer == question.answer) {
    return true;
} else {
    return false;
}
}

// Loop for all quiz questions
for (let i = 0; i < quiz.length; i++) {
 let userAnswer = prompt(
     quiz[i].questionText +
     "\nA) " + quiz[i].optionA +
     "\nB) " + quiz[i].optionB +
     "\nC) " + quiz[i].optionC +
     "\nD) " + quiz[i].optionD 
     );

// Checks and only allows A-D only
if (userAnswer == null || !/^[a-dA-D]$/.test(userAnswer)) {
    alert ("Invalid, please only enter A, B, C or D");
    i--; //Repeats the question
    continue;
}

// Check answer
if (checkAnswer(quiz[i], userAnswer)) {
    score++;
    alert ("Good job! That is correct!\nYour score is " + score + ".");
} else {
    let correctAnswer = quiz[i].answer;
    alert("Sorry that is incorrect!\nThe correct answer was " + correctAnswer + "\nYour score is " + score + "/5");
}
}
// Shows the user their final score out of 5.
alert("Quiz finished!")

if (score >= 3) {
    alert ("Your final score was " + score + "/" + quiz.length + " - You WIN!!!");
} else {
    alert ("Your final score was " + score + "/" + quiz.length + " - You lost! Try again next time");
}

let rating = prompt ("Please rate this quiz out of five!\n1) Terrible\n2) Needs improvments\n3)Good, nothing special\n4) I loved it.\n5)OMG!! Best quiz ever!");

while (rating < 1 || rating > 5) {
    alert ("Invalid, please rate this quiz out of 5.")
    rating = prompt ("Please rate this quiz out of five!\n1) Terrible\n2) Needs improvments\n3)Good, nothing special\n4) I loved it.\n5)OMG!! Best quiz ever!")
}
while (isNaN(rating)) {
    alert ("Invalid character, please enter a valid option")
    rating = prompt ("Please rate this quiz out of five!\n1) Terrible\n2) Needs improvments\n3)Good, nothing special\n4) I loved it.\n5)OMG!! Best quiz ever!")
}
alert ("Thank you for the review")